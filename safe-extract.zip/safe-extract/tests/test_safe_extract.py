import io
import json
import os
import stat
import struct
import subprocess
import sys
import tarfile
import tempfile
import unittest
import zipfile
from unittest import mock

SCRIPT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCRIPT_PATH = os.path.join(SCRIPT_DIR, "scripts", "safe_extract.py")
sys.path.insert(0, os.path.join(SCRIPT_DIR, "scripts"))

import safe_extract  # noqa: E402


HAS_LINUX_API = (
    sys.platform.startswith("linux")
    and hasattr(os, "O_NOFOLLOW")
    and hasattr(os, "O_DIRECTORY")
    and os.open in os.supports_dir_fd
    and os.mkdir in os.supports_dir_fd
)


def file_entry(name, data, mode=0o777):
    info = tarfile.TarInfo(name)
    info.size = len(data)
    info.mode = mode
    return info, data


def directory_entry(name):
    info = tarfile.TarInfo(name)
    info.type = tarfile.DIRTYPE
    info.mode = 0o777
    return info, None


def link_entry(name, target, hardlink=False):
    info = tarfile.TarInfo(name)
    info.type = tarfile.LNKTYPE if hardlink else tarfile.SYMTYPE
    info.linkname = target
    return info, None


def fifo_entry(name):
    info = tarfile.TarInfo(name)
    info.type = tarfile.FIFOTYPE
    return info, None


def write_tar(path, entries, compressed=False):
    mode = "w:gz" if compressed else "w"
    with tarfile.open(path, mode) as archive:
        for info, data in entries:
            if data is None:
                archive.addfile(info)
            else:
                archive.addfile(info, io.BytesIO(data))


class PathAndPolicyTests(unittest.TestCase):
    def test_posix_path_normalization(self):
        builder = safe_extract.PlanBuilder(safe_extract.Limits(), False)
        parts, error = builder._validate_path("./alpha//beta/file.txt")
        self.assertIsNone(error)
        self.assertEqual(parts, ("alpha", "beta", "file.txt"))

    def test_path_traversal_is_never_sanitized(self):
        builder = safe_extract.PlanBuilder(safe_extract.Limits(), False)
        for name in ("../outside", "alpha/../../outside", "/absolute"):
            with self.subTest(name=name):
                parts, error = builder._validate_path(name)
                self.assertIsNone(parts)
                self.assertIn(error, ("PATH_TRAVERSAL", "ABSOLUTE_PATH"))

    def test_skipped_link_becomes_normal_directory_for_child(self):
        builder = safe_extract.PlanBuilder(safe_extract.Limits(), False)
        builder.add("link", "symlink", 0, link_target="/etc")
        builder.add("link/file", "regular", 4)
        self.assertEqual([entry.action for entry in builder.plan.entries], ["skip", "file"])
        self.assertEqual(builder.plan.entries[1].parts, ("link", "file"))
        self.assertEqual(builder.plan.skipped[0]["reason"], "LINK_NOT_ALLOWED")

    def test_strict_mode_rejects_link(self):
        builder = safe_extract.PlanBuilder(safe_extract.Limits(), True)
        with self.assertRaises(safe_extract.ExtractError) as caught:
            builder.add("link", "symlink", 0, link_target="/etc")
        self.assertEqual(caught.exception.code, "LINK_NOT_ALLOWED")

    def test_duplicate_file_is_skipped(self):
        builder = safe_extract.PlanBuilder(safe_extract.Limits(), False)
        builder.add("same", "regular", 1)
        builder.add("same", "regular", 1)
        self.assertEqual(builder.plan.entries[0].action, "file")
        self.assertEqual(builder.plan.entries[1].action, "skip")
        self.assertEqual(builder.plan.skipped[0]["reason"], "DUPLICATE_PATH")


class ArchivePlanningTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = self.temporary.name

    def tearDown(self):
        self.temporary.cleanup()

    def test_tar_gz_plan_preserves_skip_and_file_actions(self):
        archive = os.path.join(self.root, "plan.tar.gz")
        write_tar(
            archive,
            [
                link_entry("link", "/etc"),
                file_entry("link/file", b"data"),
                fifo_entry("pipe"),
            ],
            compressed=True,
        )
        archive_format, plan, _prepared = safe_extract._build_plan(
            archive, safe_extract.Limits(), False, self.root
        )
        self.assertEqual(archive_format, "tar")
        self.assertEqual([entry.action for entry in plan.entries], ["skip", "file", "skip"])
        self.assertEqual(len(plan.skipped), 2)
        self.assertEqual(plan.declared_size, 4)

    def test_zip_plan_detects_unix_symlink(self):
        archive = os.path.join(self.root, "plan.zip")
        link = zipfile.ZipInfo("link")
        link.create_system = 3
        link.external_attr = (stat.S_IFLNK | 0o777) << 16
        with zipfile.ZipFile(archive, "w") as output:
            output.writestr(link, "/etc")
            output.writestr("safe", b"data")
        archive_format, plan, _prepared = safe_extract._build_plan(
            archive, safe_extract.Limits(), False, self.root
        )
        self.assertEqual(archive_format, "zip")
        self.assertEqual([entry.action for entry in plan.entries], ["skip", "file"])
        self.assertEqual(plan.skipped[0]["type"], "symlink")

    def test_oversized_gnu_longname_fails_before_tarfile_parsing(self):
        archive = os.path.join(self.root, "longname.tar.gz")
        info = tarfile.TarInfo("a" * (2 * 1024 * 1024))
        info.size = 0
        with tarfile.open(archive, "w:gz", format=tarfile.GNU_FORMAT) as output:
            output.addfile(info)
        limits = safe_extract.Limits(max_file_size=16, max_total_size=16)
        with self.assertRaises(safe_extract.ExtractError) as caught:
            safe_extract._build_plan(archive, limits, False, self.root)
        self.assertEqual(caught.exception.code, "TAR_METADATA_TOO_LARGE")

    def test_normal_gnu_longname_is_supported(self):
        archive = os.path.join(self.root, "normal-longname.tar")
        name = "a" * 200
        info, data = file_entry(name, b"data")
        with tarfile.open(archive, "w", format=tarfile.GNU_FORMAT) as output:
            output.addfile(info, io.BytesIO(data))
        archive_format, plan, _ = safe_extract._build_plan(
            archive, safe_extract.Limits(), False, self.root
        )
        self.assertEqual(archive_format, "tar")
        self.assertEqual(plan.entries[0].action, "file")
        self.assertEqual(plan.entries[0].parts, (name,))

    def test_oversized_pax_header_fails_before_tarfile_parsing(self):
        archive = os.path.join(self.root, "large-pax.tar")
        info, data = file_entry("file", b"")
        info.pax_headers = {"comment": "x" * (1024 * 1024 + 1)}
        with tarfile.open(archive, "w", format=tarfile.PAX_FORMAT) as output:
            output.addfile(info, io.BytesIO(data))
        with self.assertRaises(safe_extract.ExtractError) as caught:
            safe_extract._build_plan(archive, safe_extract.Limits(), False, self.root)
        self.assertEqual(caught.exception.code, "TAR_METADATA_TOO_LARGE")

    def test_normal_pax_header_is_supported(self):
        archive = os.path.join(self.root, "normal-pax.tar")
        info, data = file_entry("file", b"data")
        info.pax_headers = {"comment": "ordinary metadata"}
        with tarfile.open(archive, "w", format=tarfile.PAX_FORMAT) as output:
            output.addfile(info, io.BytesIO(data))
        _, plan, _ = safe_extract._build_plan(
            archive, safe_extract.Limits(), False, self.root
        )
        self.assertEqual(plan.entries[0].action, "file")
        self.assertEqual(plan.declared_size, 4)

    def test_zip_entry_count_is_rejected_before_zipfile_construction(self):
        archive = os.path.join(self.root, "count.zip")
        with zipfile.ZipFile(archive, "w") as output:
            output.writestr("one", b"1")
            output.writestr("two", b"2")
        limits = safe_extract.Limits(max_files=1)
        with mock.patch.object(
            safe_extract.zipfile, "ZipFile", side_effect=AssertionError("must not parse")
        ):
            with self.assertRaises(safe_extract.ExtractError) as caught:
                safe_extract._build_plan(archive, limits, False, self.root)
        self.assertEqual(caught.exception.code, "TOO_MANY_ENTRIES")

    def test_zip_entry_count_mismatch_is_corrupt(self):
        archive = os.path.join(self.root, "count-mismatch.zip")
        with zipfile.ZipFile(archive, "w") as output:
            output.writestr("one", b"1")
            output.writestr("two", b"2")
        with open(archive, "rb") as source:
            data = bytearray(source.read())
        struct.pack_into("<HH", data, len(data) - 22 + 8, 0, 0)
        with open(archive, "wb") as output:
            output.write(data)
        with self.assertRaises(safe_extract.ExtractError) as caught:
            safe_extract._build_plan(archive, safe_extract.Limits(), False, self.root)
        self.assertEqual(caught.exception.code, "CORRUPT_ARCHIVE")

    def test_directory_with_payload_is_rejected_as_corrupt(self):
        archive = os.path.join(self.root, "bad-directory.tar")
        write_tar(
            archive,
            [directory_entry("dir/"), file_entry("dir/file", b"data")],
        )
        with open(archive, "rb") as source:
            data = bytearray(source.read())
        header = bytearray(data[:512])
        header[124:136] = b"%011o\x00" % 512
        header[148:156] = b"        "
        checksum = sum(header)
        header[148:156] = b"%06o\x00 " % checksum
        data[:512] = header
        with open(archive, "wb") as output:
            output.write(data)
        with self.assertRaises(safe_extract.ExtractError) as caught:
            safe_extract._build_plan(archive, safe_extract.Limits(), False, self.root)
        self.assertEqual(caught.exception.code, "CORRUPT_ARCHIVE")

    def test_nonzero_data_after_tar_end_is_rejected(self):
        archive = os.path.join(self.root, "trailing.tar")
        write_tar(archive, [file_entry("file", b"data")])
        with open(archive, "ab") as output:
            output.write(b"x" * 512)
        with self.assertRaises(safe_extract.ExtractError) as caught:
            safe_extract._build_plan(archive, safe_extract.Limits(), False, self.root)
        self.assertEqual(caught.exception.code, "CORRUPT_ARCHIVE")

    def test_global_pax_is_rejected_to_prevent_metadata_amplification(self):
        archive = os.path.join(self.root, "global-pax.tar")
        payload = b"6 k=v\n"
        global_info = tarfile.TarInfo("global")
        global_info.type = tarfile.XGLTYPE
        global_info.size = len(payload)
        with tarfile.open(archive, "w", format=tarfile.PAX_FORMAT) as output:
            output.addfile(global_info, io.BytesIO(payload))
            output.addfile(file_entry("file", b"")[0])
        with self.assertRaises(safe_extract.ExtractError) as caught:
            safe_extract._build_plan(archive, safe_extract.Limits(), False, self.root)
        self.assertEqual(caught.exception.code, "UNSUPPORTED_TAR_FEATURE")

    def test_pax_size_override_is_rejected(self):
        archive = os.path.join(self.root, "pax-size.tar")
        info, data = file_entry("file", b"")
        info.pax_headers = {"size": "0"}
        with tarfile.open(archive, "w", format=tarfile.PAX_FORMAT) as output:
            output.addfile(info, io.BytesIO(data))
        with self.assertRaises(safe_extract.ExtractError) as caught:
            safe_extract._build_plan(archive, safe_extract.Limits(), False, self.root)
        self.assertEqual(caught.exception.code, "UNSUPPORTED_TAR_FEATURE")

    def test_gnu_sparse_is_rejected(self):
        archive = os.path.join(self.root, "sparse.tar")
        write_tar(archive, [file_entry("file", b"")])
        with open(archive, "rb") as source:
            data = bytearray(source.read())
        header = bytearray(data[:512])
        header[156] = ord("S")
        header[148:156] = b"        "
        header[148:156] = b"%06o\x00 " % sum(header)
        data[:512] = header
        with open(archive, "wb") as output:
            output.write(data)
        with self.assertRaises(safe_extract.ExtractError) as caught:
            safe_extract._build_plan(archive, safe_extract.Limits(), False, self.root)
        self.assertEqual(caught.exception.code, "UNSUPPORTED_TAR_FEATURE")

    def test_empty_tar_with_valid_end_blocks_is_supported(self):
        archive = os.path.join(self.root, "empty.tar")
        write_tar(archive, [])
        archive_format, plan, _ = safe_extract._build_plan(
            archive, safe_extract.Limits(), False, self.root
        )
        self.assertEqual(archive_format, "tar")
        self.assertEqual(plan.entries, [])

    def test_bzip2_and_xz_tar_are_supported(self):
        for suffix, mode in (("bz2", "w:bz2"), ("xz", "w:xz")):
            with self.subTest(suffix=suffix):
                archive = os.path.join(self.root, "compressed.tar." + suffix)
                info, data = file_entry("file", b"data")
                with tarfile.open(archive, mode) as output:
                    output.addfile(info, io.BytesIO(data))
                archive_format, plan, _ = safe_extract._build_plan(
                    archive, safe_extract.Limits(), False, self.root
                )
                self.assertEqual(archive_format, "tar")
                self.assertEqual(plan.entries[0].action, "file")

    def test_classic_eocd_65535_count_does_not_require_zip64(self):
        source_archive = os.path.join(self.root, "one-entry.zip")
        with zipfile.ZipFile(source_archive, "w") as output:
            output.writestr("a", b"")
        with open(source_archive, "rb") as source:
            data = source.read()
        central_start = data.index(b"PK\x01\x02")
        eocd_offset = data.index(b"PK\x05\x06", central_start)
        central_unit = data[central_start:eocd_offset]
        central_size = len(central_unit) * 65535
        classic_eocd = struct.pack(
            "<4s4H2LH",
            b"PK\x05\x06",
            0,
            0,
            65535,
            65535,
            central_size,
            0,
            0,
        )
        archive = os.path.join(self.root, "classic-65535.zip")
        with open(archive, "wb") as output:
            output.write(central_unit * 65535)
            output.write(classic_eocd)
        safe_extract.archive_preflight.preflight_zip(archive, 65535, 4096)

    def test_zip64_archive_is_supported(self):
        archive = os.path.join(self.root, "zip64.zip")
        with zipfile.ZipFile(archive, "w") as output:
            output.writestr("file", b"data")
        with open(archive, "rb") as source:
            original = source.read()
        eocd_offset = len(original) - 22
        eocd = struct.unpack("<4s4H2LH", original[eocd_offset:])
        central_size, central_offset = eocd[5], eocd[6]
        zip64_record = struct.pack(
            "<4sQ2H2L4Q",
            b"PK\x06\x06",
            44,
            45,
            45,
            0,
            0,
            1,
            1,
            central_size,
            central_offset,
        )
        locator = struct.pack(
            "<4sLQL", b"PK\x06\x07", 0, eocd_offset, 1
        )
        zip64_eocd = struct.pack(
            "<4s4H2LH",
            b"PK\x05\x06",
            0,
            0,
            0xFFFF,
            0xFFFF,
            0xFFFFFFFF,
            0xFFFFFFFF,
            0,
        )
        with open(archive, "wb") as output:
            output.write(original[:eocd_offset] + zip64_record + locator + zip64_eocd)
        archive_format, plan, _ = safe_extract._build_plan(
            archive, safe_extract.Limits(), False, self.root
        )
        self.assertEqual(archive_format, "zip")
        self.assertEqual(plan.entries[0].action, "file")


@unittest.skipUnless(HAS_LINUX_API, "requires Linux dir_fd and O_NOFOLLOW support")
class LinuxExtractionTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = self.temporary.name

    def tearDown(self):
        self.temporary.cleanup()

    def path(self, name):
        return os.path.join(self.root, name)

    def extract(self, archive, destination="output", strict=False, limits=None):
        return safe_extract.extract_archive(
            archive, self.path(destination), limits=limits, strict=strict
        )

    def assert_no_path(self, path):
        self.assertFalse(os.path.lexists(path), "unexpected path: {}".format(path))

    def test_normal_tar_gz_and_fixed_permissions(self):
        archive = self.path("normal.tar.gz")
        write_tar(
            archive,
            [
                directory_entry("docs/"),
                file_entry("docs/hello.txt", b"hello"),
                file_entry("./script.sh", b"#!/bin/sh\n"),
            ],
            compressed=True,
        )
        result = self.extract(archive)
        destination = self.path("output")
        self.assertEqual(result["status"], "success")
        self.assertEqual(result["files_extracted"], 2)
        self.assertEqual(result["skipped"], [])
        with open(os.path.join(destination, "docs", "hello.txt"), "rb") as source:
            self.assertEqual(source.read(), b"hello")
        self.assertEqual(stat.S_IMODE(os.stat(destination).st_mode), 0o700)
        self.assertEqual(stat.S_IMODE(os.stat(os.path.join(destination, "docs")).st_mode), 0o700)
        self.assertEqual(
            stat.S_IMODE(os.stat(os.path.join(destination, "script.sh")).st_mode), 0o600
        )

    def test_symlink_attack_is_skipped_without_escape(self):
        outside = self.path("outside")
        os.mkdir(outside)
        canary = os.path.join(outside, "canary")
        with open(canary, "wb") as output:
            output.write(b"unchanged")

        archive = self.path("symlink.tar")
        write_tar(
            archive,
            [
                link_entry("link", outside),
                file_entry("link/pwned", b"safe"),
            ],
        )
        result = self.extract(archive)
        self.assertEqual(result["status"], "partial")
        self.assertEqual(len(result["skipped"]), 1)
        self.assertEqual(result["skipped"][0]["reason"], "LINK_NOT_ALLOWED")
        self.assert_no_path(os.path.join(outside, "pwned"))
        with open(canary, "rb") as source:
            self.assertEqual(source.read(), b"unchanged")
        materialized = os.path.join(self.path("output"), "link")
        self.assertTrue(os.path.isdir(materialized))
        self.assertFalse(os.path.islink(materialized))
        with open(os.path.join(materialized, "pwned"), "rb") as source:
            self.assertEqual(source.read(), b"safe")

    def test_strict_symlink_rejects_and_cleans_destination(self):
        outside = self.path("outside")
        os.mkdir(outside)
        archive = self.path("strict.tar")
        write_tar(
            archive,
            [link_entry("link", outside), file_entry("link/pwned", b"bad")],
        )
        with self.assertRaises(safe_extract.ExtractError) as caught:
            self.extract(archive, strict=True)
        self.assertEqual(caught.exception.code, "LINK_NOT_ALLOWED")
        self.assert_no_path(self.path("output"))
        self.assert_no_path(os.path.join(outside, "pwned"))

    def test_hardlink_and_fifo_are_skipped(self):
        outside = self.path("outside")
        os.mkdir(outside)
        canary = os.path.join(outside, "canary")
        with open(canary, "wb") as output:
            output.write(b"unchanged")

        archive = self.path("special.tar")
        write_tar(
            archive,
            [
                file_entry("safe", b"ok"),
                link_entry("hardlink", canary, hardlink=True),
                fifo_entry("pipe"),
            ],
        )
        result = self.extract(archive)
        self.assertEqual(result["status"], "partial")
        self.assertEqual(result["files_extracted"], 1)
        self.assertEqual(len(result["skipped"]), 2)
        self.assert_no_path(os.path.join(self.path("output"), "hardlink"))
        self.assert_no_path(os.path.join(self.path("output"), "pipe"))
        with open(canary, "rb") as source:
            self.assertEqual(source.read(), b"unchanged")

    def test_traversal_and_absolute_paths_are_skipped(self):
        archive = self.path("paths.tar")
        absolute_target = self.path("absolute-target")
        write_tar(
            archive,
            [
                file_entry("../escaped", b"bad"),
                file_entry(absolute_target, b"bad"),
                file_entry("safe", b"ok"),
            ],
        )
        result = self.extract(archive)
        self.assertEqual(result["status"], "partial")
        self.assertEqual(result["files_extracted"], 1)
        self.assertEqual(len(result["skipped"]), 2)
        self.assert_no_path(self.path("escaped"))
        self.assert_no_path(absolute_target)

    def test_duplicate_file_keeps_first_content(self):
        archive = self.path("duplicate.tar")
        write_tar(
            archive,
            [file_entry("same", b"first"), file_entry("same", b"second")],
        )
        result = self.extract(archive)
        self.assertEqual(result["status"], "partial")
        self.assertEqual(result["skipped"][0]["reason"], "DUPLICATE_PATH")
        with open(os.path.join(self.path("output"), "same"), "rb") as source:
            self.assertEqual(source.read(), b"first")

    def test_file_directory_conflict_is_skipped(self):
        archive = self.path("conflict.tar")
        write_tar(
            archive,
            [file_entry("node", b"file"), file_entry("node/child", b"child")],
        )
        result = self.extract(archive)
        self.assertEqual(result["status"], "partial")
        self.assertEqual(result["skipped"][0]["reason"], "PATH_CONFLICT")
        self.assertTrue(os.path.isfile(os.path.join(self.path("output"), "node")))
        self.assert_no_path(os.path.join(self.path("output"), "node", "child"))

    def test_implicit_directory_and_duplicate_directory_are_safe(self):
        archive = self.path("directories.tar")
        write_tar(
            archive,
            [file_entry("a/b", b"data"), directory_entry("a/")],
        )
        result = self.extract(archive)
        self.assertEqual(result["status"], "success")
        self.assertEqual(result["directories_created"], 1)

    def test_normal_zip(self):
        archive = self.path("normal.zip")
        with zipfile.ZipFile(archive, "w") as output:
            output.writestr("folder/file.txt", b"zip data")
        result = self.extract(archive)
        self.assertEqual(result["status"], "success")
        with open(os.path.join(self.path("output"), "folder", "file.txt"), "rb") as source:
            self.assertEqual(source.read(), b"zip data")

    def test_zip_symlink_is_skipped(self):
        outside = self.path("outside")
        os.mkdir(outside)
        archive = self.path("link.zip")
        link = zipfile.ZipInfo("link")
        link.create_system = 3
        link.external_attr = (stat.S_IFLNK | 0o777) << 16
        with zipfile.ZipFile(archive, "w") as output:
            output.writestr(link, outside)
            output.writestr("safe.txt", b"safe")
        result = self.extract(archive)
        self.assertEqual(result["status"], "partial")
        self.assertEqual(result["files_extracted"], 1)
        self.assertEqual(result["skipped"][0]["type"], "symlink")
        self.assert_no_path(os.path.join(self.path("output"), "link"))
        self.assertFalse(os.listdir(outside))

    def test_entry_size_limit_fails_and_cleans(self):
        archive = self.path("large.tar")
        write_tar(archive, [file_entry("large", b"123456")])
        limits = safe_extract.Limits(max_file_size=5)
        with self.assertRaises(safe_extract.ExtractError) as caught:
            self.extract(archive, limits=limits)
        self.assertEqual(caught.exception.code, "ENTRY_TOO_LARGE")
        self.assert_no_path(self.path("output"))

    def test_total_size_limit_fails_and_cleans(self):
        archive = self.path("total.zip")
        with zipfile.ZipFile(archive, "w") as output:
            output.writestr("one", b"1234")
            output.writestr("two", b"5678")
        limits = safe_extract.Limits(max_total_size=7)
        with self.assertRaises(safe_extract.ExtractError) as caught:
            self.extract(archive, limits=limits)
        self.assertEqual(caught.exception.code, "TOTAL_SIZE_EXCEEDED")
        self.assert_no_path(self.path("output"))

    def test_entry_count_limit_fails_and_cleans(self):
        archive = self.path("count.tar")
        write_tar(archive, [file_entry("one", b"1"), file_entry("two", b"2")])
        limits = safe_extract.Limits(max_files=1)
        with self.assertRaises(safe_extract.ExtractError) as caught:
            self.extract(archive, limits=limits)
        self.assertEqual(caught.exception.code, "TOO_MANY_ENTRIES")
        self.assert_no_path(self.path("output"))

    def test_existing_destination_is_not_modified(self):
        destination = self.path("output")
        os.mkdir(destination)
        canary = os.path.join(destination, "canary")
        with open(canary, "wb") as output:
            output.write(b"unchanged")
        archive = self.path("normal.tar")
        write_tar(archive, [file_entry("file", b"data")])
        with self.assertRaises(safe_extract.ExtractError) as caught:
            self.extract(archive)
        self.assertEqual(caught.exception.code, "DESTINATION_EXISTS")
        with open(canary, "rb") as source:
            self.assertEqual(source.read(), b"unchanged")

    def test_umask_is_restored_after_extraction(self):
        archive = self.path("umask.tar")
        write_tar(archive, [file_entry("file", b"data")])
        original = os.umask(0o022)
        try:
            self.extract(archive)
            observed = os.umask(0o022)
            self.assertEqual(observed, 0o022)
        finally:
            os.umask(original)

    def test_writer_does_not_follow_preexisting_symlink(self):
        destination = self.path("output")
        outside = self.path("outside")
        os.mkdir(destination)
        os.mkdir(outside)
        os.symlink(outside, os.path.join(destination, "link"))
        writer = safe_extract.SecureWriter(destination)
        try:
            with self.assertRaises(safe_extract.ExtractError):
                writer.write_file(
                    ("link", "pwned"),
                    io.BytesIO(b"bad"),
                    3,
                    safe_extract.Limits(),
                    "link/pwned",
                )
        finally:
            writer.close()
        self.assert_no_path(os.path.join(outside, "pwned"))

    def test_corrupt_archive_fails_without_destination(self):
        archive = self.path("corrupt.bin")
        with open(archive, "wb") as output:
            output.write(b"not an archive")
        with self.assertRaises(safe_extract.ExtractError) as caught:
            self.extract(archive)
        self.assertEqual(caught.exception.code, "CORRUPT_ARCHIVE")
        self.assert_no_path(self.path("output"))

    def test_cli_partial_json(self):
        archive = self.path("partial.tar")
        write_tar(
            archive,
            [link_entry("link", "/etc"), file_entry("safe", b"ok")],
        )
        process = subprocess.run(
            [sys.executable, SCRIPT_PATH, "--archive", archive, "--dest", self.path("output")],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            universal_newlines=True,
            check=False,
        )
        self.assertEqual(process.returncode, 0, process.stderr)
        result = json.loads(process.stdout)
        self.assertEqual(result["status"], "partial")
        self.assertEqual(len(result["skipped"]), 1)

    def test_cli_strict_failure_json(self):
        archive = self.path("strict-cli.tar")
        write_tar(archive, [link_entry("link", "/etc")])
        process = subprocess.run(
            [
                sys.executable,
                SCRIPT_PATH,
                "--archive",
                archive,
                "--dest",
                self.path("output"),
                "--strict",
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            universal_newlines=True,
            check=False,
        )
        self.assertEqual(process.returncode, 1, process.stderr)
        result = json.loads(process.stdout)
        self.assertEqual(result["status"], "failed")
        self.assertEqual(result["error"]["code"], "LINK_NOT_ALLOWED")
        self.assert_no_path(self.path("output"))


if __name__ == "__main__":
    unittest.main()
