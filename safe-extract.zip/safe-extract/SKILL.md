---
name: safe-extract
description: >
  在 Linux 上安全解压 ZIP、TAR、TAR.GZ、TGZ、TAR.BZ2、TAR.XZ。
  当需要解压、展开、提取压缩包内容，或为查看、编译、安装而间接解压时使用。
  默认跳过路径穿越、链接和特殊文件并明确报告，支持严格模式，防止写出目标目录。
---

# Safe Extract

使用本 Skill 目录下的 `scripts/safe_extract.py`。只依赖 Python 3 标准库，
不需要安装 pip 包。不要调用系统解压器作为后备方案。

## 强制规则

1. 只能解压到**不存在的新目录**。父目录必须是 agent 控制的可信目录，
   不要直接使用公共可写目录作为解压根目录。
2. 不得删除或覆盖已有目标目录；目标已存在时，换一个新的专用目录。
3. 禁止直接运行 `tar`、`unzip`、`7z`、`bsdtar`，也禁止调用
   `tarfile.extract()`、`tarfile.extractall()`、`zipfile.extract()`、
   `zipfile.extractall()`。
4. 默认跳过危险条目，但必须读取并报告 JSON 中的 `status` 和 `skipped`。
5. `partial` 不是完整成功。任务仅涉及查看普通文件时可以继续；准备编译、
   安装、执行或加载产物时，必须暂停并说明缺失条目，不得自动继续。
6. 脚本拒绝归档时不得换工具绕过，不得手工重建软链接或硬链接。
7. 解压后的内容仍不可信，不得自动执行、`source`、安装或加载其中的代码、
   脚本、配置和宏。
8. 不支持的格式直接报告。不要调用其他工具解压 RAR、7z、Zstandard 等格式。

## 调用方式

将下面的 `/absolute/path/to/safe-extract` 替换为本 Skill 的实际绝对路径：

```bash
# 默认：跳过危险条目并报告
python3 /absolute/path/to/safe-extract/scripts/safe_extract.py \
  --archive /path/to/input.tar.gz \
  --dest /workspace/agent-output/result

# 严格模式：发现任何危险条目即失败
python3 /absolute/path/to/safe-extract/scripts/safe_extract.py \
  --archive /path/to/input.zip \
  --dest /workspace/agent-output/result \
  --strict
```

## 支持范围

- ZIP
- TAR
- TAR.GZ / TGZ
- TAR.BZ2
- TAR.XZ

归档按内容识别，不依赖扩展名。Linux 必须支持 `dir_fd`、`O_NOFOLLOW` 和
`O_DIRECTORY`。不满足时脚本失败，不退化为普通解压。

## 有界预检

为避免解析器在限额检查前分配大量内存，脚本先对私有快照执行预检：

- ZIP 在构造 `ZipFile` 前验证 EOCD/ZIP64、实际条目数和中央目录边界。
- TAR 先以固定块流式解压，校验头部校验和、负载边界、PAX 记录和完整结束块，
  再生成私有的未压缩 TAR 快照供 `tarfile` 读取。结束块后的非零数据视为损坏。
- TAR 物理头（包括 GNU/PAX 扩展头）计入 `--max-files`。
- GNU longname/longlink 不得超过路径上限；单个 PAX 头最大 1 MiB，TAR 元数据
  总计最大 16 MiB。
- ZIP 文件名原始长度受 `--max-path-bytes` 限制，所有条目的 extra 和 comment
  总计最大 16 MiB；中央目录整体读取也有派生上限。
- TAR 解压后的结构流上限由总大小、条目数和元数据上限共同约束。

GNU sparse、全局 PAX、会改变数据布局的 PAX `size` 覆盖、多磁盘 ZIP、ZIP64 可扩展数据区 暂不支持，遇到时
整个解压失败。普通 GNU 长路径和 PAX 扩展头仍受支持。预检元数据超限或不支持
的解析特性不会按普通危险条目跳过。

## 默认策略

| 情况 | 默认模式 | `--strict` |
| --- | --- | --- |
| 软链接、硬链接 | 跳过并报告 | 整个解压失败 |
| 设备、FIFO、Socket、其他特殊条目 | 跳过并报告 | 整个解压失败 |
| 绝对路径、`..`、空路径、非法名称 | 跳过该条目，不清洗后解压 | 整个解压失败 |
| 重复文件、文件/目录冲突 | 不覆盖，跳过并报告 | 整个解压失败 |
| 加密 ZIP 条目 | 跳过并报告 | 整个解压失败 |
| 条目数、大小或预检元数据超限 | 整个解压失败 | 整个解压失败 |
| GNU sparse、全局 PAX、PAX `size` 覆盖、多磁盘 ZIP、ZIP64 可扩展数据区 | 整个解压失败 | 整个解压失败 |
| 归档损坏、CRC 错误、读写失败 | 整个解压失败 | 整个解压失败 |

链接不会落地，也不会被跟随。被跳过的链接路径若后续包含普通文件，该路径会
作为目标目录内的新普通目录处理。例如 `link -> /etc` 被跳过后，`link/x`
只会写为 `<dest>/link/x`。

所有实际写入都使用 `dir_fd + O_NOFOLLOW`，文件使用 `O_EXCL`。目录权限固定为
`0700`，文件为 `0600`；不恢复归档属主、setuid、ACL 或其他特殊权限。

## 默认资源限额

| 参数 | 默认值 |
| --- | --- |
| `--max-archive-size` | 1073741824 字节（1 GiB） |
| `--max-files` | 10000 个归档条目（含 TAR 扩展头） |
| `--max-file-size` | 268435456 字节（256 MiB） |
| `--max-total-size` | 1073741824 字节（1 GiB） |
| `--max-depth` | 64 级 |
| `--max-path-bytes` | 4096 字节 |

限额必须为正整数。可根据任务明确调整，但不能关闭限额。压缩包声明的总大小和
实际写出的字节数都会受到限制。

## 输出契约

stdout 始终输出单行 JSON（命令行参数解析错误除外）。

完整成功：

```json
{
  "status": "success",
  "destination": "/workspace/agent-output/result",
  "files_extracted": 2,
  "skipped": []
}
```

有跳过条目：

```json
{
  "status": "partial",
  "destination": "/workspace/agent-output/result",
  "files_extracted": 1,
  "skipped": [
    {
      "entry": "bin/tool",
      "type": "symlink",
      "reason": "LINK_NOT_ALLOWED",
      "target": "/usr/bin/tool"
    }
  ]
}
```

失败：

```json
{
  "status": "failed",
  "error": {
    "code": "PATH_TRAVERSAL",
    "entry": "../outside",
    "message": "Unsafe archive entry rejected in strict mode: PATH_TRAVERSAL"
  }
}
```

- `success` 和 `partial` 的退出码均为 `0`，必须用 `status` 区分。
- `failed` 的退出码为 `1`。失败后脚本清理目标目录；若清理失败，JSON 会包含
  `cleanup_error`。
- 命令行参数错误的退出码为 `2`。
- 输出还包含归档 SHA-256、条目数、声明大小、实际字节数和目录创建数。

## 配套系统提示词

部署 agent 时，将以下规则加入系统提示词：

```text
凡需要解压、展开或提取 ZIP、TAR、TAR.GZ、TGZ、TAR.BZ2、TAR.XZ
等压缩包内容时，必须调用 safe-extract skill。
禁止直接使用 tar、unzip、7z、bsdtar、tarfile.extractall()、
zipfile.extractall() 或其他方式绕过该 skill。
必须解压到新的专用目标目录。安全解压器失败时不得换工具重试。
partial 不得视为完整成功而自动编译、安装或运行产物。
解压完成不代表内容可信，不得自动执行、安装、source 或加载解压产物。
```

系统提示词不是安全边界。若 agent 框架支持工具白名单或前置 Hook，应同时在
工具层限制其他解压入口。

## 测试

在本 Skill 目录运行：

```bash
python3 -m unittest discover -s tests -v
```

测试只使用标准库，覆盖正常 ZIP/ZIP64/TAR、GNU/PAX、链接攻击、路径穿越、
特殊文件、重复路径、预检资源限制、损坏归档和严格模式。非 Linux 平台只运行
策略与预检测试，Linux 安全写入测试会明确标记为 skipped；部署前应在目标
Linux 环境确认全部测试通过。

## 安全边界

- 应以非 root 的专用低权限用户运行。
- 保护范围是解压过程中的越界写入，不代表解压内容安全或来源可信。
- 需要验证来源时，应另外核对可信渠道提供的签名或 SHA-256。
- 该机制不用于防御已经能以同一 UID 任意修改 agent 私有目录的本地攻击者。
