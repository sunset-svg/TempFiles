"""Bounded ZIP and TAR preflight checks using only the Python stdlib."""

import bz2
import gzip
import lzma
import os
import struct
import tarfile
import tempfile

CHUNK_SIZE = 1024 * 1024
TAR_BLOCK_SIZE = 512
TAR_RECORD_PADDING = 10 * 1024
MAX_TAR_METADATA_ENTRY = 1024 * 1024
MAX_TAR_METADATA_TOTAL = 16 * 1024 * 1024
MAX_ZIP_AFFIXES_TOTAL = 16 * 1024 * 1024
ZIP_EOCD_SIZE = 22
ZIP64_LOCATOR_SIZE = 20
ZIP64_EOCD_SIZE = 56
ZIP_CENTRAL_HEADER_SIZE = 46


class ArchivePreflightError(Exception):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code
        self.message = message


def _fail(code, message):
    raise ArchivePreflightError(code, message)


def _parse_tar_number(field):
    if not field:
        _fail("CORRUPT_ARCHIVE", "Empty TAR numeric field")
    if field[0] in (0x80, 0xFF):
        value = int.from_bytes(field[1:], "big")
        if field[0] == 0xFF:
            value = -(256 ** (len(field) - 1) - value)
        return value
    try:
        value = field.split(b"\x00", 1)[0].decode("ascii", "strict")
        return int(value.strip() or "0", 8)
    except (UnicodeError, ValueError):
        _fail("CORRUPT_ARCHIVE", "Invalid TAR numeric field")


def _validate_tar_checksum(header):
    expected = _parse_tar_number(header[148:156])
    unsigned = 256 + sum(header[:148]) + sum(header[156:])
    signed = 256 + sum(
        byte if byte < 128 else byte - 256 for byte in header[:148] + header[156:]
    )
    if expected not in (unsigned, signed):
        _fail("CORRUPT_ARCHIVE", "Invalid TAR header checksum")


def _validate_pax_payload(payload):
    position = 0
    while position < len(payload):
        space = payload.find(b" ", position)
        if space <= position or not payload[position:space].isdigit():
            _fail("CORRUPT_ARCHIVE", "Malformed PAX record length")
        if space - position > 10:
            _fail("TAR_METADATA_TOO_LARGE", "PAX record length has too many digits")
        length = int(payload[position:space])
        record_end = position + length
        if length <= space - position or record_end > len(payload):
            _fail("CORRUPT_ARCHIVE", "Malformed PAX record boundary")
        equals = payload.find(b"=", space + 1, record_end)
        if equals == -1 or payload[record_end - 1 : record_end] != b"\n":
            _fail("CORRUPT_ARCHIVE", "Malformed PAX record")
        keyword = payload[space + 1 : equals]
        if not keyword:
            _fail("CORRUPT_ARCHIVE", "Empty PAX keyword")
        if keyword == b"size":
            _fail(
                "UNSUPPORTED_TAR_FEATURE",
                "PAX size overrides are not supported by the structural preflight",
            )
        if keyword.startswith(b"GNU.sparse"):
            _fail("UNSUPPORTED_TAR_FEATURE", "GNU sparse TAR entries are not supported")
        if keyword in {b"uid", b"gid", b"mtime", b"atime", b"ctime"}:
            value_length = record_end - equals - 2
            if value_length > 128:
                _fail("TAR_METADATA_TOO_LARGE", "PAX numeric field is too long")
        position = record_end


class _TarStreamWriter:
    def __init__(self, source, output, maximum_size):
        self.source = source
        self.output = output
        self.maximum_size = maximum_size
        self.total = 0

    def copy_exact(self, size, capture=False):
        if size < 0:
            _fail("CORRUPT_ARCHIVE", "Negative TAR payload size")
        if self.total + size > self.maximum_size:
            _fail("TAR_STREAM_TOO_LARGE", "Decompressed TAR exceeds its structural limit")
        remaining = size
        captured = bytearray() if capture else None
        while remaining:
            chunk = self.source.read(min(CHUNK_SIZE, remaining))
            if not chunk:
                _fail("CORRUPT_ARCHIVE", "Truncated TAR payload")
            self.output.write(chunk)
            if captured is not None:
                captured.extend(chunk)
            self.total += len(chunk)
            remaining -= len(chunk)
        return bytes(captured) if captured is not None else None

    def copy_zero_tail(self):
        while True:
            allowance = self.maximum_size - self.total
            if allowance < 0:
                _fail("TAR_STREAM_TOO_LARGE", "Decompressed TAR exceeds its structural limit")
            chunk = self.source.read(min(CHUNK_SIZE, allowance + 1))
            if not chunk:
                return
            if self.total + len(chunk) > self.maximum_size:
                _fail("TAR_STREAM_TOO_LARGE", "Decompressed TAR exceeds its structural limit")
            if any(chunk):
                _fail("CORRUPT_ARCHIVE", "Non-zero data follows the TAR end marker")
            self.output.write(chunk)
            self.total += len(chunk)


def _validate_tar_stream(source, output, maximum_size, max_files, max_path_bytes):
    writer = _TarStreamWriter(source, output, maximum_size)
    headers_seen = 0
    metadata_total = 0
    zero_payload_types = {
        tarfile.SYMTYPE,
        tarfile.LNKTYPE,
        tarfile.DIRTYPE,
        tarfile.FIFOTYPE,
        tarfile.CHRTYPE,
        tarfile.BLKTYPE,
    }
    pax_types = {tarfile.XHDTYPE, tarfile.XGLTYPE, tarfile.SOLARIS_XHDTYPE}
    long_types = {tarfile.GNUTYPE_LONGNAME, tarfile.GNUTYPE_LONGLINK}

    while True:
        header = writer.copy_exact(TAR_BLOCK_SIZE, capture=True)
        if not header:
            _fail("CORRUPT_ARCHIVE", "Empty TAR stream")
        if header == b"\x00" * TAR_BLOCK_SIZE:
            second_zero = writer.copy_exact(TAR_BLOCK_SIZE, capture=True)
            if second_zero != b"\x00" * TAR_BLOCK_SIZE:
                _fail("CORRUPT_ARCHIVE", "TAR end marker is incomplete")
            writer.copy_zero_tail()
            return

        _validate_tar_checksum(header)
        headers_seen += 1
        if headers_seen > max_files:
            _fail("TOO_MANY_ENTRIES", "TAR has too many physical headers")

        size = _parse_tar_number(header[124:136])
        if size < 0:
            _fail("CORRUPT_ARCHIVE", "Negative TAR entry size")
        entry_type = header[156:157]
        raw_name = header[:100].split(b"\x00", 1)[0]
        is_v7_directory = entry_type == tarfile.AREGTYPE and raw_name.endswith(b"/")

        if entry_type == tarfile.GNUTYPE_SPARSE:
            _fail("UNSUPPORTED_TAR_FEATURE", "GNU sparse TAR entries are not supported")
        if entry_type == tarfile.XGLTYPE:
            _fail(
                "UNSUPPORTED_TAR_FEATURE",
                "Global PAX headers are not supported because they amplify per-entry metadata",
            )
        if (entry_type in zero_payload_types or is_v7_directory) and size != 0:
            _fail("CORRUPT_ARCHIVE", "A metadata-only TAR entry declares a payload")

        capture = entry_type in pax_types
        if entry_type in long_types and size > max_path_bytes + 1:
            _fail("TAR_METADATA_TOO_LARGE", "GNU longname/longlink exceeds the path limit")
        if entry_type in pax_types and size > MAX_TAR_METADATA_ENTRY:
            _fail("TAR_METADATA_TOO_LARGE", "PAX header exceeds the per-entry limit")
        if entry_type in long_types or entry_type in pax_types:
            metadata_total += size
            if metadata_total > MAX_TAR_METADATA_TOTAL:
                _fail("TAR_METADATA_TOO_LARGE", "TAR metadata exceeds its total limit")

        payload = writer.copy_exact(size, capture=capture)
        if capture:
            _validate_pax_payload(payload)
        writer.copy_exact((-size) % TAR_BLOCK_SIZE)


def prepare_tar(snapshot, work_directory, max_files, max_total_size, max_path_bytes):
    """Validate and write a bounded, uncompressed TAR snapshot."""
    maximum_size = (
        max_total_size
        + max_files * 2 * TAR_BLOCK_SIZE
        + MAX_TAR_METADATA_TOTAL
        + TAR_RECORD_PADDING
    )
    output_fd, output_path = tempfile.mkstemp(
        prefix=".validated-", suffix=".tar", dir=work_directory
    )
    try:
        with os.fdopen(output_fd, "wb") as output, open(snapshot, "rb") as raw:
            magic = raw.read(6)
            raw.seek(0)
            if magic.startswith(b"\x1f\x8b"):
                source = gzip.GzipFile(fileobj=raw, mode="rb")
            elif magic.startswith(b"BZh"):
                source = bz2.BZ2File(raw, mode="r")
            elif magic.startswith(b"\xfd7zXZ\x00"):
                source = lzma.LZMAFile(raw, mode="r")
            else:
                source = raw
            try:
                _validate_tar_stream(
                    source, output, maximum_size, max_files, max_path_bytes
                )
            finally:
                if source is not raw:
                    source.close()
    except ArchivePreflightError:
        os.unlink(output_path)
        raise
    except Exception as exc:
        os.unlink(output_path)
        raise ArchivePreflightError("CORRUPT_ARCHIVE", str(exc))
    return output_path


def _find_eocd(source, file_size):
    if file_size < ZIP_EOCD_SIZE:
        _fail("CORRUPT_ARCHIVE", "ZIP end record is missing")
    search_start = max(0, file_size - ZIP_EOCD_SIZE - 65535)
    source.seek(search_start)
    data = source.read()
    position = data.rfind(b"PK\x05\x06")
    while position >= 0:
        absolute = search_start + position
        if absolute + ZIP_EOCD_SIZE <= file_size:
            fields = struct.unpack("<4s4H2LH", data[position : position + ZIP_EOCD_SIZE])
            if absolute + ZIP_EOCD_SIZE + fields[7] == file_size:
                return absolute, fields
        position = data.rfind(b"PK\x05\x06", 0, position)
    _fail("CORRUPT_ARCHIVE", "ZIP end record is invalid")


def preflight_zip(snapshot, max_files, max_path_bytes):
    """Bound entry count and central-directory allocation before ZipFile."""
    with open(snapshot, "rb") as source:
        file_size = os.fstat(source.fileno()).st_size
        eocd_offset, fields = _find_eocd(source, file_size)
        (
            _,
            disk_number,
            disk_start,
            entries_on_disk,
            entries_total,
            central_size,
            central_offset,
            _,
        ) = fields

        zip64 = (
            entries_on_disk == 0xFFFF
            or entries_total == 0xFFFF
            or central_size == 0xFFFFFFFF
            or central_offset == 0xFFFFFFFF
        )
        if zip64 and central_size != 0xFFFFFFFF and central_offset != 0xFFFFFFFF:
            if entries_on_disk == entries_total == 0xFFFF:
                locator_offset = eocd_offset - ZIP64_LOCATOR_SIZE
                if locator_offset >= 0:
                    source.seek(locator_offset)
                    possible_locator = source.read(ZIP64_LOCATOR_SIZE)
                else:
                    possible_locator = b""
                if (
                    len(possible_locator) != ZIP64_LOCATOR_SIZE
                    or possible_locator[:4] != b"PK\x06\x07"
                ):
                    zip64 = False

        if zip64:
            locator_offset = eocd_offset - ZIP64_LOCATOR_SIZE
            if locator_offset < 0:
                _fail("CORRUPT_ARCHIVE", "ZIP64 locator is missing")
            source.seek(locator_offset)
            locator = source.read(ZIP64_LOCATOR_SIZE)
            if len(locator) != ZIP64_LOCATOR_SIZE:
                _fail("CORRUPT_ARCHIVE", "ZIP64 locator is truncated")
            locator_fields = struct.unpack("<4sLQL", locator)
            if locator_fields[0] != b"PK\x06\x07":
                _fail("CORRUPT_ARCHIVE", "ZIP64 locator is missing")
            if locator_fields[1] != 0 or locator_fields[3] != 1:
                _fail("UNSUPPORTED_ZIP_FEATURE", "Multi-disk ZIP archives are not supported")

            record_offset = locator_offset - ZIP64_EOCD_SIZE
            if record_offset < 0:
                _fail("CORRUPT_ARCHIVE", "ZIP64 end record is missing")
            source.seek(record_offset)
            record = source.read(ZIP64_EOCD_SIZE)
            if len(record) != ZIP64_EOCD_SIZE:
                _fail("CORRUPT_ARCHIVE", "ZIP64 end record is truncated")
            record_fields = struct.unpack("<4sQ2H2L4Q", record)
            if record_fields[0] != b"PK\x06\x06":
                _fail("CORRUPT_ARCHIVE", "ZIP64 end record is invalid")
            if record_fields[1] != 44:
                _fail(
                    "UNSUPPORTED_ZIP_FEATURE",
                    "ZIP64 extensible data sectors are not supported",
                )
            if record_fields[4] != 0 or record_fields[5] != 0:
                _fail("UNSUPPORTED_ZIP_FEATURE", "Multi-disk ZIP archives are not supported")
            entries_on_disk = record_fields[6]
            entries_total = record_fields[7]
            central_size = record_fields[8]
            central_offset = record_fields[9]

        if disk_number != 0 or disk_start != 0 or entries_on_disk != entries_total:
            _fail("UNSUPPORTED_ZIP_FEATURE", "Multi-disk ZIP archives are not supported")
        if entries_total > max_files:
            _fail("TOO_MANY_ENTRIES", "ZIP has more entries than the configured limit")

        maximum_central_size = (
            max_files * (ZIP_CENTRAL_HEADER_SIZE + max_path_bytes)
            + MAX_ZIP_AFFIXES_TOTAL
        )
        if central_size > maximum_central_size:
            _fail("ZIP_METADATA_TOO_LARGE", "ZIP central directory exceeds its memory limit")

        concat = eocd_offset - central_size - central_offset
        if zip64:
            concat -= ZIP64_EOCD_SIZE + ZIP64_LOCATOR_SIZE
            if locator_fields[2] + concat != record_offset:
                _fail("CORRUPT_ARCHIVE", "ZIP64 locator points to the wrong record")
        central_start = central_offset + concat
        if central_start < 0 or central_start + central_size > file_size:
            _fail("CORRUPT_ARCHIVE", "ZIP central directory is outside the archive")

        source.seek(central_start)
        remaining = central_size
        actual_entries = 0
        affixes_total = 0
        while remaining:
            if remaining < ZIP_CENTRAL_HEADER_SIZE:
                _fail("CORRUPT_ARCHIVE", "ZIP central directory is truncated")
            header = source.read(ZIP_CENTRAL_HEADER_SIZE)
            if len(header) != ZIP_CENTRAL_HEADER_SIZE:
                _fail("CORRUPT_ARCHIVE", "ZIP central directory is truncated")
            fields = struct.unpack("<4s4B4HL2L5H2L", header)
            if fields[0] != b"PK\x01\x02":
                _fail("CORRUPT_ARCHIVE", "Invalid ZIP central-directory signature")
            name_length, extra_length, comment_length = fields[12:15]
            entry_size = (
                ZIP_CENTRAL_HEADER_SIZE + name_length + extra_length + comment_length
            )
            if entry_size > remaining:
                _fail("CORRUPT_ARCHIVE", "ZIP central-directory entry is out of bounds")
            if name_length > max_path_bytes:
                _fail("PATH_TOO_LONG", "ZIP entry name exceeds the preflight path limit")
            affixes_total += extra_length + comment_length
            if affixes_total > MAX_ZIP_AFFIXES_TOTAL:
                _fail("ZIP_METADATA_TOO_LARGE", "ZIP entry metadata exceeds its total limit")
            actual_entries += 1
            if actual_entries > max_files:
                _fail("TOO_MANY_ENTRIES", "ZIP has more entries than the configured limit")
            source.seek(name_length + extra_length + comment_length, os.SEEK_CUR)
            remaining -= entry_size

        if actual_entries != entries_total:
            _fail("CORRUPT_ARCHIVE", "ZIP entry count does not match its end record")
