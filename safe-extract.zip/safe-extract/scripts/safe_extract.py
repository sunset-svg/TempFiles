#!/usr/bin/env python3
"""Safely extract ZIP and TAR archives on Linux using only the stdlib."""

import argparse
import hashlib
import json
import os
import shutil
import stat
import sys
import tarfile
import tempfile
import zipfile
from collections import OrderedDict
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

import archive_preflight

CHUNK_SIZE = 1024 * 1024
MAX_COMPONENT_BYTES = 255
DIR_FD_CACHE_SIZE = 128


@dataclass(frozen=True)
class Limits:
    max_archive_size: int = 1024 * 1024 * 1024
    max_files: int = 10000
    max_file_size: int = 256 * 1024 * 1024
    max_total_size: int = 1024 * 1024 * 1024
    max_depth: int = 64
    max_path_bytes: int = 4096


@dataclass
class PlannedEntry:
    raw_name: str
    kind: str
    size: int
    action: str
    parts: Optional[Tuple[str, ...]] = None


@dataclass
class ArchivePlan:
    entries: List[PlannedEntry] = field(default_factory=list)
    skipped: List[Dict[str, str]] = field(default_factory=list)
    entries_seen: int = 0
    declared_size: int = 0


class ExtractError(Exception):
    def __init__(self, code: str, message: str, entry: Optional[str] = None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.entry = entry
        self.cleanup_error = None  # type: Optional[str]


class PlanBuilder:
    def __init__(self, limits: Limits, strict: bool):
        self.limits = limits
        self.strict = strict
        self.plan = ArchivePlan()
        self.nodes = {}  # type: Dict[Tuple[str, ...], str]

    def add(
        self,
        name: str,
        kind: str,
        size: int,
        link_target: Optional[str] = None,
        encrypted: bool = False,
    ) -> None:
        self.plan.entries_seen += 1
        if self.plan.entries_seen > self.limits.max_files:
            raise ExtractError(
                "TOO_MANY_ENTRIES",
                "Archive has more than {} entries".format(self.limits.max_files),
                name,
            )

        if not isinstance(size, int) or size < 0:
            raise ExtractError("INVALID_ARCHIVE_METADATA", "Invalid entry size", name)

        if kind != "directory":
            if size > self.limits.max_file_size:
                raise ExtractError(
                    "ENTRY_TOO_LARGE",
                    "Entry exceeds the {} byte limit".format(self.limits.max_file_size),
                    name,
                )
            self.plan.declared_size += size
            if self.plan.declared_size > self.limits.max_total_size:
                raise ExtractError(
                    "TOTAL_SIZE_EXCEEDED",
                    "Archive exceeds the {} byte total limit".format(
                        self.limits.max_total_size
                    ),
                    name,
                )

        parts, path_error = self._validate_path(name)
        if path_error:
            self._skip(name, kind, size, path_error, link_target)
            return

        if kind in ("symlink", "hardlink"):
            self._skip(name, kind, size, "LINK_NOT_ALLOWED", link_target)
            return

        if kind not in ("regular", "directory"):
            self._skip(name, kind, size, "SPECIAL_FILE_NOT_ALLOWED", link_target)
            return

        if encrypted:
            self._skip(name, kind, size, "ENCRYPTED_ENTRY_NOT_SUPPORTED", link_target)
            return

        assert parts is not None
        if not parts:
            if kind == "directory":
                self.plan.entries.append(
                    PlannedEntry(name, kind, size, "ignore", parts)
                )
            else:
                self._skip(name, kind, size, "EMPTY_PATH", link_target)
            return

        for index in range(1, len(parts)):
            parent = parts[:index]
            parent_type = self.nodes.get(parent)
            if parent_type == "file":
                self._skip(name, kind, size, "PATH_CONFLICT", link_target)
                return
            if parent_type is None:
                self.nodes[parent] = "directory"

        existing = self.nodes.get(parts)
        if existing == "file":
            reason = "DUPLICATE_PATH" if kind == "regular" else "PATH_CONFLICT"
            self._skip(name, kind, size, reason, link_target)
            return
        if existing == "directory":
            if kind == "directory":
                self.plan.entries.append(
                    PlannedEntry(name, kind, size, "ignore", parts)
                )
            else:
                self._skip(name, kind, size, "PATH_CONFLICT", link_target)
            return

        self.nodes[parts] = "file" if kind == "regular" else "directory"
        action = "file" if kind == "regular" else "mkdir"
        self.plan.entries.append(PlannedEntry(name, kind, size, action, parts))

    def _validate_path(
        self, name: str
    ) -> Tuple[Optional[Tuple[str, ...]], Optional[str]]:
        if not isinstance(name, str) or not name or "\x00" in name:
            return None, "INVALID_NAME"
        if name.startswith("/"):
            return None, "ABSOLUTE_PATH"

        try:
            encoded = os.fsencode(name)
        except (UnicodeError, ValueError):
            return None, "INVALID_NAME"
        if len(encoded) > self.limits.max_path_bytes:
            return None, "PATH_TOO_LONG"

        parts = []  # type: List[str]
        for component in name.split("/"):
            if component in ("", "."):
                continue
            if component == "..":
                return None, "PATH_TRAVERSAL"
            try:
                component_bytes = os.fsencode(component)
            except (UnicodeError, ValueError):
                return None, "INVALID_NAME"
            if len(component_bytes) > MAX_COMPONENT_BYTES:
                return None, "PATH_TOO_LONG"
            parts.append(component)

        if len(parts) > self.limits.max_depth:
            return None, "PATH_TOO_DEEP"
        return tuple(parts), None

    def _skip(
        self,
        name: str,
        kind: str,
        size: int,
        reason: str,
        link_target: Optional[str],
    ) -> None:
        if self.strict:
            raise ExtractError(
                reason,
                "Unsafe archive entry rejected in strict mode: {}".format(reason),
                name,
            )

        record = {"entry": name, "type": kind, "reason": reason}
        if link_target is not None:
            record["target"] = link_target
        self.plan.skipped.append(record)
        self.plan.entries.append(PlannedEntry(name, kind, size, "skip"))


class SecureWriter:
    def __init__(self, destination: str):
        flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
        self.root_fd = os.open(destination, flags)
        self.dir_fds = OrderedDict()  # type: OrderedDict[Tuple[str, ...], int]
        self.files_written = 0
        self.directories_created = 0
        self.bytes_written = 0

    def make_directory(self, parts: Tuple[str, ...], entry: str) -> None:
        self._get_directory(parts, entry)

    def write_file(
        self,
        parts: Tuple[str, ...],
        source,
        expected_size: int,
        limits: Limits,
        entry: str,
    ) -> None:
        parent_fd = self._get_directory(parts[:-1], entry)
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW
        try:
            file_fd = os.open(parts[-1], flags, 0o600, dir_fd=parent_fd)
        except OSError as exc:
            raise ExtractError("SAFE_FILE_OPEN_FAILED", str(exc), entry)

        try:
            with os.fdopen(file_fd, "wb") as output:
                self._copy(source, output, expected_size, limits, entry)
        except ExtractError:
            raise
        except Exception as exc:
            raise ExtractError("ENTRY_COPY_FAILED", str(exc), entry)

        self.files_written += 1

    def _copy(self, source, output, expected_size: int, limits: Limits, entry: str) -> None:
        written = 0
        while True:
            read_size = min(CHUNK_SIZE, expected_size - written + 1)
            chunk = source.read(read_size)
            if not chunk:
                break
            new_written = written + len(chunk)
            if new_written > expected_size:
                raise ExtractError(
                    "SIZE_MISMATCH", "Entry contains more data than declared", entry
                )
            if new_written > limits.max_file_size:
                raise ExtractError("ENTRY_TOO_LARGE", "Actual entry size exceeded", entry)
            if self.bytes_written + new_written > limits.max_total_size:
                raise ExtractError(
                    "TOTAL_SIZE_EXCEEDED", "Actual total size exceeded", entry
                )
            output.write(chunk)
            written = new_written

        if written != expected_size:
            raise ExtractError(
                "SIZE_MISMATCH",
                "Entry size mismatch: expected {}, got {}".format(expected_size, written),
                entry,
            )
        self.bytes_written += written

    def _get_directory(self, parts: Tuple[str, ...], entry: str) -> int:
        if not parts:
            return self.root_fd

        cached = self.dir_fds.get(parts)
        if cached is not None:
            self.dir_fds.move_to_end(parts)
            return cached

        parent_fd = self._get_directory(parts[:-1], entry)
        name = parts[-1]
        flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
        try:
            directory_fd = os.open(name, flags, dir_fd=parent_fd)
        except FileNotFoundError:
            try:
                os.mkdir(name, mode=0o700, dir_fd=parent_fd)
                self.directories_created += 1
            except FileExistsError:
                pass
            except OSError as exc:
                raise ExtractError("SAFE_DIRECTORY_CREATE_FAILED", str(exc), entry)
            try:
                directory_fd = os.open(name, flags, dir_fd=parent_fd)
            except OSError as exc:
                raise ExtractError("SAFE_DIRECTORY_OPEN_FAILED", str(exc), entry)
        except OSError as exc:
            raise ExtractError("SAFE_DIRECTORY_OPEN_FAILED", str(exc), entry)

        self.dir_fds[parts] = directory_fd
        while len(self.dir_fds) > DIR_FD_CACHE_SIZE:
            _, old_fd = self.dir_fds.popitem(last=False)
            try:
                os.close(old_fd)
            except OSError:
                pass
        return directory_fd

    def close(self) -> None:
        for directory_fd in self.dir_fds.values():
            try:
                os.close(directory_fd)
            except OSError:
                pass
        self.dir_fds.clear()
        try:
            os.close(self.root_fd)
        except OSError:
            pass


def _validate_limits(limits: Limits) -> None:
    for field_name in (
        "max_archive_size",
        "max_files",
        "max_file_size",
        "max_total_size",
        "max_depth",
        "max_path_bytes",
    ):
        if getattr(limits, field_name) <= 0:
            raise ExtractError("INVALID_LIMIT", "{} must be positive".format(field_name))


def _ensure_linux_support() -> None:
    if not sys.platform.startswith("linux"):
        raise ExtractError("UNSUPPORTED_PLATFORM", "Safe extraction requires Linux")
    if not hasattr(os, "O_NOFOLLOW") or not hasattr(os, "O_DIRECTORY"):
        raise ExtractError("UNSUPPORTED_PLATFORM", "Required open flags are unavailable")
    if os.open not in os.supports_dir_fd or os.mkdir not in os.supports_dir_fd:
        raise ExtractError("UNSUPPORTED_PLATFORM", "dir_fd operations are unavailable")


def _zip_name(info: zipfile.ZipInfo) -> str:
    return getattr(info, "orig_filename", info.filename)


def _zip_kind(info: zipfile.ZipInfo) -> str:
    mode = info.external_attr >> 16
    file_type = stat.S_IFMT(mode)
    if info.is_dir() or file_type == stat.S_IFDIR:
        return "directory"
    if file_type == stat.S_IFLNK:
        return "symlink"
    if file_type not in (0, stat.S_IFREG):
        return "special"
    return "regular"


def _tar_kind(member: tarfile.TarInfo) -> str:
    if member.isreg():
        return "regular"
    if member.isdir():
        return "directory"
    if member.issym():
        return "symlink"
    if member.islnk():
        return "hardlink"
    if member.isfifo():
        return "fifo"
    if member.ischr() or member.isblk():
        return "device"
    return "special"


def _build_zip_plan(snapshot: str, limits: Limits, strict: bool) -> ArchivePlan:
    builder = PlanBuilder(limits, strict)
    try:
        with zipfile.ZipFile(snapshot, "r") as archive:
            for info in archive.infolist():
                builder.add(
                    _zip_name(info),
                    _zip_kind(info),
                    info.file_size,
                    encrypted=bool(info.flag_bits & 0x1),
                )
    except ExtractError:
        raise
    except (zipfile.BadZipFile, OSError, EOFError) as exc:
        raise ExtractError("CORRUPT_ARCHIVE", str(exc))
    return builder.plan


def _build_tar_plan(snapshot: str, limits: Limits, strict: bool) -> ArchivePlan:
    builder = PlanBuilder(limits, strict)
    try:
        with open(snapshot, "rb") as source:
            if source.read(512) == b"\x00" * 512:
                return builder.plan
        with tarfile.open(snapshot, mode="r:") as archive:
            while True:
                member = archive.next()
                if member is None:
                    break
                builder.add(
                    member.name,
                    _tar_kind(member),
                    member.size,
                    link_target=member.linkname if member.issym() or member.islnk() else None,
                )
    except ExtractError:
        raise
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise ExtractError("CORRUPT_ARCHIVE", str(exc))
    return builder.plan


def _build_plan(
    snapshot: str, limits: Limits, strict: bool, work_directory: str
) -> Tuple[str, ArchivePlan, str]:
    try:
        is_zip = zipfile.is_zipfile(snapshot)
    except OSError as exc:
        raise ExtractError("ARCHIVE_OPEN_FAILED", str(exc))

    try:
        if is_zip:
            archive_preflight.preflight_zip(
                snapshot, limits.max_files, limits.max_path_bytes
            )
            return "zip", _build_zip_plan(snapshot, limits, strict), snapshot

        prepared = archive_preflight.prepare_tar(
            snapshot,
            work_directory,
            limits.max_files,
            limits.max_total_size,
            limits.max_path_bytes,
        )
        return "tar", _build_tar_plan(prepared, limits, strict), prepared
    except archive_preflight.ArchivePreflightError as exc:
        raise ExtractError(exc.code, exc.message)


def _snapshot_archive(archive: str, directory: str, maximum_size: int):
    snapshot = os.path.join(directory, "archive.bin")
    digest = hashlib.sha256()
    total = 0
    try:
        source_fd = os.open(archive, os.O_RDONLY)
        with os.fdopen(source_fd, "rb") as source:
            source_stat = os.fstat(source.fileno())
            if not stat.S_ISREG(source_stat.st_mode):
                raise ExtractError("INVALID_ARCHIVE", "Archive must be a regular file")
            if source_stat.st_size > maximum_size:
                raise ExtractError("ARCHIVE_TOO_LARGE", "Compressed archive is too large")
            with open(snapshot, "xb") as output:
                while True:
                    chunk = source.read(min(CHUNK_SIZE, maximum_size - total + 1))
                    if not chunk:
                        break
                    total += len(chunk)
                    if total > maximum_size:
                        raise ExtractError(
                            "ARCHIVE_TOO_LARGE", "Compressed archive is too large"
                        )
                    digest.update(chunk)
                    output.write(chunk)
    except ExtractError:
        raise
    except OSError as exc:
        raise ExtractError("ARCHIVE_OPEN_FAILED", str(exc))
    return snapshot, total, digest.hexdigest()


def _extract_zip(snapshot: str, plan: ArchivePlan, writer: SecureWriter, limits: Limits) -> None:
    try:
        with zipfile.ZipFile(snapshot, "r") as archive:
            infos = archive.infolist()
            if len(infos) != len(plan.entries):
                raise ExtractError("ARCHIVE_CHANGED", "Archive entries changed during extraction")
            for info, planned in zip(infos, plan.entries):
                if _zip_name(info) != planned.raw_name:
                    raise ExtractError("ARCHIVE_CHANGED", "Archive entry order changed")
                try:
                    if planned.action == "file":
                        with archive.open(info, "r") as source:
                            writer.write_file(
                                planned.parts, source, planned.size, limits, planned.raw_name
                            )
                    elif planned.action == "mkdir":
                        writer.make_directory(planned.parts, planned.raw_name)
                except ExtractError:
                    raise
                except Exception as exc:
                    raise ExtractError("ARCHIVE_EXTRACTION_FAILED", str(exc), planned.raw_name)
    except ExtractError:
        raise
    except (zipfile.BadZipFile, OSError, EOFError) as exc:
        raise ExtractError("CORRUPT_ARCHIVE", str(exc))


def _extract_tar(snapshot: str, plan: ArchivePlan, writer: SecureWriter, limits: Limits) -> None:
    if not plan.entries:
        return
    try:
        with tarfile.open(snapshot, mode="r:") as archive:
            index = 0
            while True:
                member = archive.next()
                if member is None:
                    break
                if index >= len(plan.entries):
                    raise ExtractError("ARCHIVE_CHANGED", "Archive gained entries")
                planned = plan.entries[index]
                index += 1
                if member.name != planned.raw_name or _tar_kind(member) != planned.kind:
                    raise ExtractError("ARCHIVE_CHANGED", "Archive entries changed")
                try:
                    if planned.action == "file":
                        source = archive.extractfile(member)
                        if source is None:
                            raise ExtractError(
                                "ARCHIVE_EXTRACTION_FAILED",
                                "No data stream for regular file",
                                planned.raw_name,
                            )
                        with source:
                            writer.write_file(
                                planned.parts, source, planned.size, limits, planned.raw_name
                            )
                    elif planned.action == "mkdir":
                        writer.make_directory(planned.parts, planned.raw_name)
                except ExtractError:
                    raise
                except Exception as exc:
                    raise ExtractError("ARCHIVE_EXTRACTION_FAILED", str(exc), planned.raw_name)
            if index != len(plan.entries):
                raise ExtractError("ARCHIVE_CHANGED", "Archive lost entries")
    except ExtractError:
        raise
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise ExtractError("CORRUPT_ARCHIVE", str(exc))


def _extract_plan(
    archive_format: str, snapshot: str, plan: ArchivePlan, destination: str, limits: Limits
) -> SecureWriter:
    try:
        writer = SecureWriter(destination)
    except OSError as exc:
        raise ExtractError("SAFE_DESTINATION_OPEN_FAILED", str(exc))
    try:
        if archive_format == "zip":
            _extract_zip(snapshot, plan, writer, limits)
        else:
            _extract_tar(snapshot, plan, writer, limits)
        return writer
    except BaseException:
        writer.close()
        raise


def extract_archive(
    archive_path: str,
    destination_path: str,
    limits: Optional[Limits] = None,
    strict: bool = False,
) -> Dict[str, object]:
    """Extract an archive, returning a JSON-serializable result dictionary."""
    limits = limits or Limits()
    _validate_limits(limits)
    _ensure_linux_support()

    archive = os.path.abspath(os.path.expanduser(archive_path))
    destination = os.path.abspath(os.path.expanduser(destination_path))
    parent = os.path.dirname(destination)
    if not os.path.isdir(parent):
        raise ExtractError("INVALID_DESTINATION", "Destination parent is not a directory")
    try:
        os.lstat(destination)
    except FileNotFoundError:
        pass
    except OSError as exc:
        raise ExtractError("INVALID_DESTINATION", str(exc))
    else:
        raise ExtractError("DESTINATION_EXISTS", "Destination must not exist")

    previous_umask = os.umask(0o077)
    destination_created = False
    completed = False
    failure = None  # type: Optional[ExtractError]
    writer = None  # type: Optional[SecureWriter]
    try:
        with tempfile.TemporaryDirectory(prefix=".safe-extract-", dir=parent) as temporary:
            snapshot, archive_size, archive_hash = _snapshot_archive(
                archive, temporary, limits.max_archive_size
            )
            archive_format, plan, prepared = _build_plan(snapshot, limits, strict, temporary)
            try:
                os.mkdir(destination, mode=0o700)
                destination_created = True
            except FileExistsError:
                raise ExtractError("DESTINATION_EXISTS", "Destination must not exist")
            except OSError as exc:
                raise ExtractError("DESTINATION_CREATE_FAILED", str(exc))

            writer = _extract_plan(archive_format, prepared, plan, destination, limits)
            result = {
                "status": "partial" if plan.skipped else "success",
                "archive": archive,
                "archive_format": archive_format,
                "archive_size": archive_size,
                "archive_sha256": archive_hash,
                "destination": destination,
                "strict": strict,
                "entries_seen": plan.entries_seen,
                "declared_size": plan.declared_size,
                "files_extracted": writer.files_written,
                "directories_created": writer.directories_created,
                "bytes_written": writer.bytes_written,
                "skipped": plan.skipped,
            }
            writer.close()
            writer = None
        completed = True
        return result
    except ExtractError as exc:
        failure = exc
        raise
    except Exception as exc:
        failure = ExtractError("INTERNAL_ERROR", str(exc))
        raise failure from exc
    finally:
        if writer is not None:
            writer.close()
        if destination_created and not completed:
            try:
                shutil.rmtree(destination)
            except OSError as exc:
                if failure is not None:
                    failure.cleanup_error = str(exc)
        os.umask(previous_umask)


def _positive_int(value: str) -> int:
    parsed = int(value)
    if parsed <= 0:
        raise argparse.ArgumentTypeError("must be a positive integer")
    return parsed


def _print_json(value: Dict[str, object]) -> None:
    sys.stdout.write(json.dumps(value, ensure_ascii=True, sort_keys=True) + "\n")


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        description="Safely extract ZIP/TAR archives on Linux without creating links."
    )
    parser.add_argument("--archive", required=True, help="Input archive")
    parser.add_argument("--dest", required=True, help="New destination directory")
    parser.add_argument(
        "--strict", action="store_true", help="Reject the archive on any unsafe entry"
    )
    parser.add_argument("--max-archive-size", type=_positive_int, default=Limits.max_archive_size)
    parser.add_argument("--max-files", type=_positive_int, default=Limits.max_files)
    parser.add_argument("--max-file-size", type=_positive_int, default=Limits.max_file_size)
    parser.add_argument("--max-total-size", type=_positive_int, default=Limits.max_total_size)
    parser.add_argument("--max-depth", type=_positive_int, default=Limits.max_depth)
    parser.add_argument("--max-path-bytes", type=_positive_int, default=Limits.max_path_bytes)
    args = parser.parse_args(argv)

    limits = Limits(
        max_archive_size=args.max_archive_size,
        max_files=args.max_files,
        max_file_size=args.max_file_size,
        max_total_size=args.max_total_size,
        max_depth=args.max_depth,
        max_path_bytes=args.max_path_bytes,
    )
    try:
        result = extract_archive(args.archive, args.dest, limits, args.strict)
        _print_json(result)
        return 0
    except ExtractError as exc:
        error = {"code": exc.code, "message": exc.message}
        if exc.entry is not None:
            error["entry"] = exc.entry
        if exc.cleanup_error is not None:
            error["cleanup_error"] = exc.cleanup_error
        _print_json({"status": "failed", "error": error})
        return 1


if __name__ == "__main__":
    sys.exit(main())
